from . import db
from .models import User, Station

def seed_demo():
    if User.query.first(): return
    users = [
        ("Admin User","admin@ev.local","admin"),
        ("Station Operator","operator@ev.local","operator"),
        ("EV Owner","owner@ev.local","owner"),
        ("Technician","tech@ev.local","technician"),
        ("Finance Officer","finance@ev.local","finance"),
        ("Fleet Manager","fleet@ev.local","fleet"),
    ]
    for name,email,role in users:
        u=User(name=name,email=email,role=role); u.set_password("123456"); db.session.add(u)
    db.session.flush()
    op=User.query.filter_by(role="operator").first()
    stations=[
        Station(name="Green Charge Hub",location="Karachi",address="Main Shahrah-e-Faisal",operator_id=op.id,chargers=12,available=8,price=45),
        Station(name="EcoSwap Station",location="Lahore",address="Gulberg Main Boulevard",operator_id=op.id,chargers=10,available=4,price=40),
        Station(name="VoltPoint",location="Islamabad",address="Blue Area",operator_id=op.id,chargers=16,available=11,price=50),
    ]
    db.session.add_all(stations); db.session.commit()
