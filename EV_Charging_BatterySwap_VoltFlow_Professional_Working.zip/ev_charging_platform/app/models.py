from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from . import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(40), default="owner")
    vehicle_type = db.Column(db.String(80), default="")
    vehicle_number = db.Column(db.String(80), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, p): self.password_hash = generate_password_hash(p)
    def check_password(self, p): return check_password_hash(self.password_hash, p)

class Station(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    location = db.Column(db.String(160), nullable=False)
    address = db.Column(db.String(240), default="")
    operator_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    chargers = db.Column(db.Integer, default=8)
    available = db.Column(db.Integer, default=5)
    price = db.Column(db.Float, default=45)
    active = db.Column(db.Boolean, default=True)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    station_id = db.Column(db.Integer, db.ForeignKey("station.id"), nullable=False)
    service_type = db.Column(db.String(40), nullable=False)
    scheduled_at = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(40), default="Booked")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Session(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("booking.id"), nullable=False)
    started_at = db.Column(db.DateTime)
    ended_at = db.Column(db.DateTime)
    units_consumed = db.Column(db.Float, default=0)
    status = db.Column(db.String(40), default="In Progress")

class CCTVVerification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("session.id"), nullable=False)
    verified_by = db.Column(db.Integer, db.ForeignKey("user.id"))
    footage_reference = db.Column(db.String(240), default="")
    verification_notes = db.Column(db.Text, default="")
    result = db.Column(db.String(30), default="Pending")
    verified_at = db.Column(db.DateTime)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("session.id"), nullable=False)
    amount = db.Column(db.Float, default=0)
    payment_method = db.Column(db.String(50), default="Demo Payment")
    status = db.Column(db.String(40), default="Pending")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class FaultReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    station_id = db.Column(db.Integer, db.ForeignKey("station.id"), nullable=False)
    equipment_type = db.Column(db.String(80), default="Charger")
    description = db.Column(db.Text, default="")
    status = db.Column(db.String(40), default="Open")
    reported_at = db.Column(db.DateTime, default=datetime.utcnow)
