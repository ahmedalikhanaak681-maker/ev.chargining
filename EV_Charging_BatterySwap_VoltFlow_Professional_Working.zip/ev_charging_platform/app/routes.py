from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from . import db, login_manager
from .models import User, Station, Booking, Session, CCTVVerification, Transaction, FaultReport

main=Blueprint("main",__name__)

@login_manager.user_loader
def load_user(uid): return User.query.get(int(uid))

@main.route("/")
def home():
    stations=Station.query.filter_by(active=True).all()
    return render_template("index.html", stations=stations)

@main.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=User.query.filter_by(email=request.form["email"].strip().lower()).first()
        if u and u.check_password(request.form["password"]):
            login_user(u); return redirect(url_for("main.dashboard"))
        flash("Invalid email or password.","danger")
    return render_template("login.html")

@main.route("/logout")
@login_required
def logout():
    logout_user(); return redirect(url_for("main.home"))

@main.route("/dashboard")
@login_required
def dashboard():
    bookings=Booking.query.filter_by(owner_id=current_user.id).order_by(Booking.created_at.desc()).all() if current_user.role=="owner" else Booking.query.order_by(Booking.created_at.desc()).all()
    stations=Station.query.all()
    sessions=Session.query.order_by(Session.id.desc()).all()
    pending=CCTVVerification.query.filter_by(result="Pending").count()
    revenue=sum(x.amount for x in Transaction.query.filter_by(status="Paid").all())
    faults=FaultReport.query.filter_by(status="Open").count()
    return render_template("dashboard.html", bookings=bookings, stations=stations, sessions=sessions, pending=pending, revenue=revenue, faults=faults)

@main.route("/book/<int:station_id>", methods=["POST"])
@login_required
def book(station_id):
    if current_user.role!="owner": flash("Only owners can create bookings.","warning"); return redirect(url_for("main.dashboard"))
    station=Station.query.get_or_404(station_id)
    if station.available<=0: flash("No equipment is currently available.","danger"); return redirect(url_for("main.home"))
    b=Booking(owner_id=current_user.id,station_id=station.id,service_type=request.form.get("service_type","Charging"),
              scheduled_at=datetime.fromisoformat(request.form["scheduled_at"]),status="Booked")
    station.available-=1; db.session.add(b); db.session.commit()
    flash("Booking created successfully.","success"); return redirect(url_for("main.dashboard"))

@main.route("/operator/confirm/<int:booking_id>")
@login_required
def confirm_booking(booking_id):
    if current_user.role not in ["operator","admin"]: flash("Access denied.","danger"); return redirect(url_for("main.dashboard"))
    b=Booking.query.get_or_404(booking_id); b.status="Confirmed"; db.session.commit()
    flash("Booking confirmed.","success"); return redirect(url_for("main.dashboard"))

@main.route("/session/<int:booking_id>/complete", methods=["POST"])
@login_required
def complete_session(booking_id):
    b=Booking.query.get_or_404(booking_id)
    s=Session(booking_id=b.id,started_at=datetime.utcnow(),ended_at=datetime.utcnow(),
              units_consumed=float(request.form.get("units",10)),status="Pending Verification")
    b.status="Pending Verification"; db.session.add(s); db.session.flush()
    db.session.add(CCTVVerification(session_id=s.id,result="Pending"))
    db.session.commit(); flash("Session completed and sent for CCTV verification.","success")
    return redirect(url_for("main.dashboard"))

@main.route("/cctv/<int:session_id>", methods=["POST"])
@login_required
def verify_cctv(session_id):
    if current_user.role not in ["operator","admin"]: flash("Only authorized operators/admins can verify CCTV.","danger"); return redirect(url_for("main.dashboard"))
    s=Session.query.get_or_404(session_id); v=CCTVVerification.query.filter_by(session_id=s.id).first()
    result=request.form.get("result","Not Confirmed"); v.result=result; v.verified_by=current_user.id
    v.footage_reference=request.form.get("footage_reference","Camera-01 | Demo Time Range")
    v.verification_notes=request.form.get("notes",""); v.verified_at=datetime.utcnow()
    s.status="Verified" if result=="Confirmed" else "Disputed"
    b=Booking.query.get(s.booking_id); b.status=s.status
    if result=="Confirmed":
        amount=s.units_consumed * 45
        db.session.add(Transaction(session_id=s.id,amount=amount,status="Paid"))
        flash(f"CCTV confirmed. Fee of Rs. {amount:,.0f} created.","success")
    else: flash("CCTV did not confirm the service. No fee was charged; case flagged for review.","warning")
    db.session.commit(); return redirect(url_for("main.dashboard"))

@main.route("/fault", methods=["POST"])
@login_required
def fault():
    station=Station.query.get_or_404(int(request.form["station_id"]))
    db.session.add(FaultReport(station_id=station.id,equipment_type=request.form["equipment_type"],description=request.form["description"]))
    db.session.commit(); flash("Fault report submitted to maintenance.","success"); return redirect(url_for("main.dashboard"))

@main.route("/health")
def health(): return {"status":"ok","service":"EV Charging & Battery-Swap Platform"}
