# VoltFlow EV Charging & Battery Swap

## Easiest Windows run
1. Install Python 3.10+ and make sure `python` works in Command Prompt.
2. Extract this folder.
3. Double-click `start.bat`.
4. Open http://127.0.0.1:5000

## Manual run in VS Code
```bat
cd ev_charging_platform
python -m venv venv
venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

Demo accounts:
- Owner: owner@ev.local / 123456
- Operator: operator@ev.local / 123456
- Admin: admin@ev.local / 123456

The SQLite database `ev_platform.db` is created automatically on first run.
